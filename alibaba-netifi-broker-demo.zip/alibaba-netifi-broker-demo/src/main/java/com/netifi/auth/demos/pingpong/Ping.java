package com.netifi.auth.demos.pingpong;

import com.netifi.broker.BrokerClient;
import com.netifi.broker.rsocket.BrokerSocket;
import com.netifi.common.tags.Tags;
import java.time.Duration;
import org.HdrHistogram.Recorder;
import reactor.core.publisher.Mono;

public class Ping {
  public static void main(String... args) {

    BrokerClient build =
        BrokerClient.tcp()
            .host("netifibroker.alibaba.net")
            .port(8001)
            .group("pongClient")
            .disableSsl()
            .jwt("eyJ0eXAiOiJKV1QiLCJpc3MiOiJSU29ja2V0QnJva2VyIiwiYWxnIjoiUlMyNTYiLCJpYXQiOjE1NzE0MTQzODksImV4cCI6MTU3MTQxNDM5MH0.eyJhbGlJZCI6IjQxNTc0ODA5NTM2NzUyMjMiLCJzdWIiOiJ0ZXN0aW5nLWFwcCIsImF1ZCI6ImphY2t5LmNoZW5sYkBhbGliYWJhLWluYy5jb20iLCJzYXMiOlsiZGVmYXVsdCIsImFjY291bnQiLCJ0cmFuc2FjdGlvbiJdLCJyb2xlcyI6WyJpbnRlcm5hbCJdLCJvcmdzIjpbImFsaWJhYmEiLCJhbGlwYXkiXX0.fdHa8pNgNoYTaWzd338cjiHJ_Mynv-vlWZfpHwTmbBOuJN4QeqYT9G-T5-Dnt1xHBNNWXbulDKgBDzdwqrZNtxpBAlONrmXKUpudjhaTB4h-iK9pAe2CQ9chpaCxjGe7OSr4CHIvr3dKIYV7E69h5Exp9eTy6oUAMGXRsws1jcku_U9_UavBu_AIFydMDlRh6X_MQbnsijkWBzjcXZPNktFGIB6ayU9TOJqMYHub0adWFsly44xiZIlpWTZYP6Lj6HKPpVkXgg9NIbdNna6ICyGa-D0E7lyKpgDnxgcwxrr-ga8NYvzqW7Qo9zAgRV2u38fWv-ILiSKa_UBqI5L83A")
            .poolSize(2)
            .build();

    BrokerSocket pong = build.groupNamedRSocket("pongHandler", "pongServer", Tags.empty());

    PingClient pingClient = new PingClient(Mono.just(pong));

    Recorder recorder = pingClient.startTracker(Duration.ofSeconds(1));

    int count = 1_000_000_000;

    pingClient
        .startPingPong(count, recorder)
        .retry()
        .doOnError(Throwable::printStackTrace)
        .doOnTerminate(() -> System.out.println("Sent " + count + " messages."))
        .blockLast();
    System.out.println("HERE1");
  }
}
